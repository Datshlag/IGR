var searchData=
[
  ['remoteclient',['RemoteClient',['../classRemoteClient.html#a39280daa273d198244dd7084b1150313',1,'RemoteClient']]],
  ['remotecontrol',['RemoteControl',['../classRemoteControl.html#adbe3adb1e50b865dd7b0937715b40332',1,'RemoteControl']]]
];
