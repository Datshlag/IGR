var searchData=
[
  ['send',['send',['../classRemoteClient.html#ad14bdcb0ae285619ce231f8e6aad6b0b',1,'RemoteClient']]],
  ['sendrequest',['sendRequest',['../classRemoteControl.html#a0c45149dda61f4878eb839971324960c',1,'RemoteControl']]]
];
