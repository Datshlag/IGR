var searchData=
[
  ['remoteclient',['RemoteClient',['../classRemoteClient.html',1,'RemoteClient'],['../classRemoteClient.html#a39280daa273d198244dd7084b1150313',1,'RemoteClient.RemoteClient()']]],
  ['remotecontrol',['RemoteControl',['../classRemoteControl.html',1,'RemoteControl'],['../classRemoteControl.html#adbe3adb1e50b865dd7b0937715b40332',1,'RemoteControl.RemoteControl()']]]
];
