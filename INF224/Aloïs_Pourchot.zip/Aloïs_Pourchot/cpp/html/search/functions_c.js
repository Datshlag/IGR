var searchData=
[
  ['picture',['Picture',['../classPicture.html#ae71db353784869ca50fd695c6c89c9f3',1,'Picture::Picture()'],['../classPicture.html#a5a385595e86d57a60fc3ee0deac7a434',1,'Picture::Picture(const string &amp;name, const string &amp;pathname, const double &amp;_latitude, const double &amp;_longitude)']]],
  ['play',['play',['../classMultimediaObject.html#a4fc54cf0e9fe39e1b885f995f49f9194',1,'MultimediaObject::play()'],['../classPicture.html#a9c3aab87ad22bf2020c50fa3e1845e40',1,'Picture::play()'],['../classVideo.html#a61a4f3672781ab2db2d79dbbb2b1c228',1,'Video::play()']]],
  ['playmultimediaobject',['playMultimediaObject',['../classData.html#a627fcf83d707dd0cef70245fe7785f4f',1,'Data']]],
  ['processrequest',['processRequest',['../classData.html#a1e03c91a77ed0555dae82727dfcc8df9',1,'Data']]]
];
