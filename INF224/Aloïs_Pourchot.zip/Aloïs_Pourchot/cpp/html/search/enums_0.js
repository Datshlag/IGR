var searchData=
[
  ['errors',['Errors',['../classcppu_1_1Socket.html#a49ea5cb079bd7ae97ecf7eb30c9d9e5f',1,'cppu::Socket']]]
];
