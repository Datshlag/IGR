var searchData=
[
  ['load',['load',['../classData.html#a1f31af0bd1cde50acd39b811245fe2c8',1,'Data']]]
];
