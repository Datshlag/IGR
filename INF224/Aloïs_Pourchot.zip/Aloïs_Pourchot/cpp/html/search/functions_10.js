var searchData=
[
  ['video',['Video',['../classVideo.html#ac973e3d02151bb2bf7b75deda0c2ca5a',1,'Video::Video()'],['../classVideo.html#a0e70b25d96356f5ea3413f8f56cef897',1,'Video::Video(const string &amp;name, const string &amp;pathname, const int &amp;_length)']]]
];
