var searchData=
[
  ['close',['close',['../classcppu_1_1Socket.html#ab958ef8a0f0495cf3a1c57a2ad4a34fc',1,'cppu::Socket::close()'],['../classcppu_1_1ServerSocket.html#ae7647cfb5beaf504a846f6ecfdd197c4',1,'cppu::ServerSocket::close()']]],
  ['connect',['connect',['../classcppu_1_1Socket.html#af6db3840caee709738f0e2a9ff814e5d',1,'cppu::Socket']]],
  ['createcnx',['createCnx',['../classcppu_1_1TCPServer.html#abe314b95a31c88b479c81ec9bf123c65',1,'cppu::TCPServer']]]
];
