var searchData=
[
  ['multimediaobject',['MultimediaObject',['../classMultimediaObject.html#abba8b5f14970dcd1f035c25dd6cdc0bc',1,'MultimediaObject::MultimediaObject()'],['../classMultimediaObject.html#ac08b63898b63faedcab9f03fa4d44506',1,'MultimediaObject::MultimediaObject(const string &amp;name, const string &amp;pathname)']]]
];
