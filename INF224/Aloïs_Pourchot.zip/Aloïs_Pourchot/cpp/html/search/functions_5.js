var searchData=
[
  ['film',['Film',['../classFilm.html#af2835db2b0ef3a87aaa3222f4d9d1ae3',1,'Film::Film()'],['../classFilm.html#a49b995034abaf3bea5637def0e4fa506',1,'Film::Film(string name, string pathname, int _length, int *_chapters, int _numberOfChapters)']]]
];
