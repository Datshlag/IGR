var searchData=
[
  ['inputseparator',['inputSeparator',['../classcppu_1_1SocketBuffer.html#a77dfe31ad3d5660322d788daf213534e',1,'cppu::SocketBuffer']]],
  ['isclosed',['isClosed',['../classcppu_1_1Socket.html#a726c2e6be413fe4e0584a23a173ae540',1,'cppu::Socket::isClosed()'],['../classcppu_1_1ServerSocket.html#aa3ca8fed354955eeb45af3a2021c04cb',1,'cppu::ServerSocket::isClosed()']]]
];
