var searchData=
[
  ['error',['error',['../classcppu_1_1TCPServer.html#afc47ca4476d9c75d5ea88f73e2acd6d5',1,'cppu::TCPServer']]],
  ['errors',['Errors',['../classcppu_1_1Socket.html#a49ea5cb079bd7ae97ecf7eb30c9d9e5f',1,'cppu::Socket']]]
];
