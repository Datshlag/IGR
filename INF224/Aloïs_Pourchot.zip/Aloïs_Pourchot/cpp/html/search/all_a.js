var searchData=
[
  ['newfilm',['newFilm',['../classData.html#abf84f4ca94b966ffe9f0a5272e4048d7',1,'Data::newFilm(const string &amp;name)'],['../classData.html#aa14f12c39b4d568353606420b691296f',1,'Data::newFilm(istream &amp;is)']]],
  ['newgroup',['newGroup',['../classData.html#a94d766d884a27444fdca887a60e1162c',1,'Data']]],
  ['newpicture',['newPicture',['../classData.html#a1fb51b0d2aee38a233b505c8e4fb862d',1,'Data::newPicture(const string &amp;name)'],['../classData.html#ac0d33face47c9aa31c5ced3bba1ba348',1,'Data::newPicture(istream &amp;is)']]],
  ['newvideo',['newVideo',['../classData.html#a9a86e93e191dc4244c18928b908861cc',1,'Data::newVideo(const string &amp;name)'],['../classData.html#a9e7919b3ca3390c0002cd2ba2854bbc4',1,'Data::newVideo(istream &amp;is)']]]
];
