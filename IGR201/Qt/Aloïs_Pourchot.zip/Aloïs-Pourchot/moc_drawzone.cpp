/****************************************************************************
** Meta object code from reading C++ file 'drawzone.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "drawzone.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'drawzone.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DrawZone[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x05,
      28,    9,    9,    9, 0x05,
      52,    9,    9,    9, 0x05,
      77,    9,    9,    9, 0x05,
     100,    9,    9,    9, 0x05,
     124,    9,    9,    9, 0x05,
     145,    9,    9,    9, 0x05,
     171,    9,    9,    9, 0x05,

 // slots: signature, parameters, type, tag, flags
     195,    9,    9,    9, 0x0a,
     222,    9,    9,    9, 0x0a,
     246,    9,    9,    9, 0x0a,
     273,    9,    9,    9, 0x0a,
     305,    9,    9,    9, 0x0a,
     333,    9,    9,    9, 0x0a,
     366,    9,    9,    9, 0x0a,
     399,    9,    9,    9, 0x0a,
     427,    9,    9,    9, 0x0a,
     451,    9,    9,    9, 0x0a,
     471,    9,    9,    9, 0x0a,
     496,    9,    9,    9, 0x0a,
     513,    9,    9,    9, 0x0a,
     542,    9,    9,    9, 0x0a,
     562,    9,    9,    9, 0x0a,
     583,    9,    9,    9, 0x0a,
     598,    9,    9,    9, 0x0a,
     618,    9,    9,    9, 0x0a,
     634,    9,    9,    9, 0x0a,
     657,    9,    9,    9, 0x0a,
     666,    9,    9,    9, 0x0a,
     681,    9,    9,    9, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_DrawZone[] = {
    "DrawZone\0\0drawZoneClicked()\0"
    "penCapStyleChanged(int)\0"
    "penJoinStyleChanged(int)\0"
    "shapeStyleChanged(int)\0currentModeChanged(int)\0"
    "AAStateChanged(bool)\0fillingStateChanged(bool)\0"
    "fillingRuleChanged(int)\0"
    "setCurrentPenColor(QColor)\0"
    "setCurrentPenWidth(int)\0"
    "setCurrentPenCapStyle(int)\0"
    "setCurrentPenCapStyle(QAction*)\0"
    "setCurrentPenJoinStyle(int)\0"
    "setCurrentPenJoinStyle(QAction*)\0"
    "setCurrentObjectToDraw(QAction*)\0"
    "setCurrentObjectToDraw(int)\0"
    "setFillingColor(QColor)\0setCurrentMode(int)\0"
    "setCurrentMode(QAction*)\0setDrawable(int)\0"
    "setFillingRule(Qt::FillRule)\0"
    "setFillingRule(int)\0fillDrawZone(QColor)\0"
    "toggleAA(bool)\0toggleFilling(bool)\0"
    "emptyDrawList()\0clearSelectedElement()\0"
    "cancel()\0saveDrawList()\0openDrawList()\0"
};

void DrawZone::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        DrawZone *_t = static_cast<DrawZone *>(_o);
        switch (_id) {
        case 0: _t->drawZoneClicked(); break;
        case 1: _t->penCapStyleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->penJoinStyleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->shapeStyleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->currentModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->AAStateChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->fillingStateChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->fillingRuleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->setCurrentPenColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 9: _t->setCurrentPenWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setCurrentPenCapStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setCurrentPenCapStyle((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 12: _t->setCurrentPenJoinStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->setCurrentPenJoinStyle((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 14: _t->setCurrentObjectToDraw((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 15: _t->setCurrentObjectToDraw((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->setFillingColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 17: _t->setCurrentMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->setCurrentMode((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 19: _t->setDrawable((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->setFillingRule((*reinterpret_cast< Qt::FillRule(*)>(_a[1]))); break;
        case 21: _t->setFillingRule((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->fillDrawZone((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 23: _t->toggleAA((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->toggleFilling((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->emptyDrawList(); break;
        case 26: _t->clearSelectedElement(); break;
        case 27: _t->cancel(); break;
        case 28: _t->saveDrawList(); break;
        case 29: _t->openDrawList(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData DrawZone::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject DrawZone::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_DrawZone,
      qt_meta_data_DrawZone, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &DrawZone::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *DrawZone::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *DrawZone::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DrawZone))
        return static_cast<void*>(const_cast< DrawZone*>(this));
    return QWidget::qt_metacast(_clname);
}

int DrawZone::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    }
    return _id;
}

// SIGNAL 0
void DrawZone::drawZoneClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void DrawZone::penCapStyleChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void DrawZone::penJoinStyleChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DrawZone::shapeStyleChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void DrawZone::currentModeChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void DrawZone::AAStateChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void DrawZone::fillingStateChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void DrawZone::fillingRuleChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
