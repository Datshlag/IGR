/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "drawzone.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionPen_color;
    QAction *actionPen_size;
    QAction *actionSquare_cap;
    QAction *actionFlat_cap;
    QAction *actionRound_cap;
    QAction *actionBevel_join;
    QAction *actionMiter_join;
    QAction *actionRound_join;
    QAction *actionEllipse;
    QAction *actionLine;
    QAction *actionRectangle;
    QAction *actionPolygon;
    QAction *actionFree_draw;
    QAction *actionDraw;
    QAction *actionSelect;
    QAction *actionAnnuler;
    QAction *actionClear;
    QAction *actionPolyline;
    QAction *actionAntialiasing;
    QAction *actionSave;
    QAction *actionOpen;
    QAction *actionDelete;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QHBoxLayout *horizontalLayout_2;
    DrawZone *widget;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout_3;
    QFormLayout *formLayout;
    QLabel *penSizeLabel;
    QLabel *capStyleLabel;
    QSpinBox *penSizeSpinBox;
    QComboBox *capStyleComboBox;
    QComboBox *joinStyleComboBox;
    QLabel *joinStyleLabel;
    QLabel *colorSelectionLabel;
    DrawZone *widget_2;
    QCheckBox *AACheckBox;
    QWidget *widget_3;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout;
    QFormLayout *formLayout_2;
    QCheckBox *fillCheckBox;
    QComboBox *fillRuleComboBox;
    QLabel *label;
    QComboBox *shapeTypeComboBox;
    QGroupBox *groupBox_4;
    QFormLayout *formLayout_6;
    QFormLayout *formLayout_5;
    QRadioButton *drawRadioButton;
    QRadioButton *selectRadioButton;
    QSpacerItem *verticalSpacer;
    QMenuBar *menuBar;
    QMenu *menuFichier;
    QMenu *menuStylo;
    QMenu *menuPen_join_style;
    QMenu *menuPen_join_style_2;
    QMenu *menuShapes;
    QMenu *menuEdition;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1097, 645);
        MainWindow->setMouseTracking(true);
        actionPen_color = new QAction(MainWindow);
        actionPen_color->setObjectName(QString::fromUtf8("actionPen_color"));
        actionPen_size = new QAction(MainWindow);
        actionPen_size->setObjectName(QString::fromUtf8("actionPen_size"));
        actionSquare_cap = new QAction(MainWindow);
        actionSquare_cap->setObjectName(QString::fromUtf8("actionSquare_cap"));
        actionSquare_cap->setCheckable(true);
        actionSquare_cap->setChecked(true);
        actionFlat_cap = new QAction(MainWindow);
        actionFlat_cap->setObjectName(QString::fromUtf8("actionFlat_cap"));
        actionFlat_cap->setCheckable(true);
        actionRound_cap = new QAction(MainWindow);
        actionRound_cap->setObjectName(QString::fromUtf8("actionRound_cap"));
        actionRound_cap->setCheckable(true);
        actionBevel_join = new QAction(MainWindow);
        actionBevel_join->setObjectName(QString::fromUtf8("actionBevel_join"));
        actionBevel_join->setCheckable(true);
        actionBevel_join->setChecked(true);
        actionMiter_join = new QAction(MainWindow);
        actionMiter_join->setObjectName(QString::fromUtf8("actionMiter_join"));
        actionMiter_join->setCheckable(true);
        actionRound_join = new QAction(MainWindow);
        actionRound_join->setObjectName(QString::fromUtf8("actionRound_join"));
        actionRound_join->setCheckable(true);
        actionEllipse = new QAction(MainWindow);
        actionEllipse->setObjectName(QString::fromUtf8("actionEllipse"));
        actionEllipse->setCheckable(true);
        actionLine = new QAction(MainWindow);
        actionLine->setObjectName(QString::fromUtf8("actionLine"));
        actionLine->setCheckable(true);
        actionLine->setChecked(true);
        actionRectangle = new QAction(MainWindow);
        actionRectangle->setObjectName(QString::fromUtf8("actionRectangle"));
        actionRectangle->setCheckable(true);
        actionPolygon = new QAction(MainWindow);
        actionPolygon->setObjectName(QString::fromUtf8("actionPolygon"));
        actionPolygon->setCheckable(true);
        actionFree_draw = new QAction(MainWindow);
        actionFree_draw->setObjectName(QString::fromUtf8("actionFree_draw"));
        actionFree_draw->setCheckable(true);
        actionDraw = new QAction(MainWindow);
        actionDraw->setObjectName(QString::fromUtf8("actionDraw"));
        actionDraw->setCheckable(true);
        actionDraw->setChecked(true);
        actionSelect = new QAction(MainWindow);
        actionSelect->setObjectName(QString::fromUtf8("actionSelect"));
        actionSelect->setCheckable(true);
        actionAnnuler = new QAction(MainWindow);
        actionAnnuler->setObjectName(QString::fromUtf8("actionAnnuler"));
        actionAnnuler->setShortcutContext(Qt::WindowShortcut);
        actionClear = new QAction(MainWindow);
        actionClear->setObjectName(QString::fromUtf8("actionClear"));
        actionPolyline = new QAction(MainWindow);
        actionPolyline->setObjectName(QString::fromUtf8("actionPolyline"));
        actionAntialiasing = new QAction(MainWindow);
        actionAntialiasing->setObjectName(QString::fromUtf8("actionAntialiasing"));
        actionAntialiasing->setCheckable(true);
        actionAntialiasing->setChecked(true);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QString::fromUtf8("actionSave"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        actionDelete = new QAction(MainWindow);
        actionDelete->setObjectName(QString::fromUtf8("actionDelete"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setMouseTracking(true);
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        widget = new DrawZone(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        widget->setMinimumSize(QSize(800, 600));
        widget->setMouseTracking(true);

        horizontalLayout_2->addWidget(widget);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy1);
        formLayout_3 = new QFormLayout(groupBox_2);
        formLayout_3->setSpacing(6);
        formLayout_3->setContentsMargins(11, 11, 11, 11);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        penSizeLabel = new QLabel(groupBox_2);
        penSizeLabel->setObjectName(QString::fromUtf8("penSizeLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, penSizeLabel);

        capStyleLabel = new QLabel(groupBox_2);
        capStyleLabel->setObjectName(QString::fromUtf8("capStyleLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, capStyleLabel);

        penSizeSpinBox = new QSpinBox(groupBox_2);
        penSizeSpinBox->setObjectName(QString::fromUtf8("penSizeSpinBox"));

        formLayout->setWidget(0, QFormLayout::FieldRole, penSizeSpinBox);

        capStyleComboBox = new QComboBox(groupBox_2);
        capStyleComboBox->setObjectName(QString::fromUtf8("capStyleComboBox"));

        formLayout->setWidget(1, QFormLayout::FieldRole, capStyleComboBox);

        joinStyleComboBox = new QComboBox(groupBox_2);
        joinStyleComboBox->setObjectName(QString::fromUtf8("joinStyleComboBox"));

        formLayout->setWidget(2, QFormLayout::FieldRole, joinStyleComboBox);

        joinStyleLabel = new QLabel(groupBox_2);
        joinStyleLabel->setObjectName(QString::fromUtf8("joinStyleLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, joinStyleLabel);

        colorSelectionLabel = new QLabel(groupBox_2);
        colorSelectionLabel->setObjectName(QString::fromUtf8("colorSelectionLabel"));

        formLayout->setWidget(3, QFormLayout::LabelRole, colorSelectionLabel);

        widget_2 = new DrawZone(groupBox_2);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));

        formLayout->setWidget(3, QFormLayout::FieldRole, widget_2);

        AACheckBox = new QCheckBox(groupBox_2);
        AACheckBox->setObjectName(QString::fromUtf8("AACheckBox"));
        AACheckBox->setChecked(true);

        formLayout->setWidget(4, QFormLayout::LabelRole, AACheckBox);

        widget_3 = new QWidget(groupBox_2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));

        formLayout->setWidget(4, QFormLayout::FieldRole, widget_3);


        formLayout_3->setLayout(0, QFormLayout::LabelRole, formLayout);


        verticalLayout_2->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        sizePolicy1.setHeightForWidth(groupBox_3->sizePolicy().hasHeightForWidth());
        groupBox_3->setSizePolicy(sizePolicy1);
        gridLayout = new QGridLayout(groupBox_3);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        formLayout_2 = new QFormLayout();
        formLayout_2->setSpacing(6);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        fillCheckBox = new QCheckBox(groupBox_3);
        fillCheckBox->setObjectName(QString::fromUtf8("fillCheckBox"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, fillCheckBox);

        fillRuleComboBox = new QComboBox(groupBox_3);
        fillRuleComboBox->setObjectName(QString::fromUtf8("fillRuleComboBox"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, fillRuleComboBox);

        label = new QLabel(groupBox_3);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label);

        shapeTypeComboBox = new QComboBox(groupBox_3);
        shapeTypeComboBox->setObjectName(QString::fromUtf8("shapeTypeComboBox"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, shapeTypeComboBox);


        gridLayout->addLayout(formLayout_2, 0, 0, 1, 1);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        formLayout_6 = new QFormLayout(groupBox_4);
        formLayout_6->setSpacing(6);
        formLayout_6->setContentsMargins(11, 11, 11, 11);
        formLayout_6->setObjectName(QString::fromUtf8("formLayout_6"));
        formLayout_5 = new QFormLayout();
        formLayout_5->setSpacing(6);
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        drawRadioButton = new QRadioButton(groupBox_4);
        drawRadioButton->setObjectName(QString::fromUtf8("drawRadioButton"));
        drawRadioButton->setChecked(true);

        formLayout_5->setWidget(0, QFormLayout::LabelRole, drawRadioButton);

        selectRadioButton = new QRadioButton(groupBox_4);
        selectRadioButton->setObjectName(QString::fromUtf8("selectRadioButton"));

        formLayout_5->setWidget(0, QFormLayout::FieldRole, selectRadioButton);


        formLayout_6->setLayout(0, QFormLayout::SpanningRole, formLayout_5);


        verticalLayout_2->addWidget(groupBox_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        verticalLayout_2->setStretch(0, 4);
        verticalLayout_2->setStretch(1, 4);

        verticalLayout->addLayout(verticalLayout_2);


        horizontalLayout_2->addWidget(groupBox);

        horizontalLayout_2->setStretch(0, 6);
        horizontalLayout_2->setStretch(1, 1);

        horizontalLayout->addLayout(horizontalLayout_2);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1097, 25));
        menuFichier = new QMenu(menuBar);
        menuFichier->setObjectName(QString::fromUtf8("menuFichier"));
        menuStylo = new QMenu(menuBar);
        menuStylo->setObjectName(QString::fromUtf8("menuStylo"));
        menuPen_join_style = new QMenu(menuStylo);
        menuPen_join_style->setObjectName(QString::fromUtf8("menuPen_join_style"));
        menuPen_join_style_2 = new QMenu(menuStylo);
        menuPen_join_style_2->setObjectName(QString::fromUtf8("menuPen_join_style_2"));
        menuShapes = new QMenu(menuBar);
        menuShapes->setObjectName(QString::fromUtf8("menuShapes"));
        menuEdition = new QMenu(menuBar);
        menuEdition->setObjectName(QString::fromUtf8("menuEdition"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuFichier->menuAction());
        menuBar->addAction(menuEdition->menuAction());
        menuBar->addAction(menuStylo->menuAction());
        menuBar->addAction(menuShapes->menuAction());
        menuFichier->addAction(actionOpen);
        menuFichier->addAction(actionSave);
        menuStylo->addAction(actionPen_color);
        menuStylo->addAction(actionPen_size);
        menuStylo->addSeparator();
        menuStylo->addAction(menuPen_join_style->menuAction());
        menuStylo->addAction(menuPen_join_style_2->menuAction());
        menuStylo->addSeparator();
        menuStylo->addAction(actionAntialiasing);
        menuPen_join_style->addAction(actionSquare_cap);
        menuPen_join_style->addAction(actionFlat_cap);
        menuPen_join_style->addAction(actionRound_cap);
        menuPen_join_style_2->addAction(actionBevel_join);
        menuPen_join_style_2->addAction(actionMiter_join);
        menuPen_join_style_2->addAction(actionRound_join);
        menuShapes->addAction(actionLine);
        menuShapes->addAction(actionPolyline);
        menuShapes->addAction(actionPolygon);
        menuShapes->addSeparator();
        menuShapes->addAction(actionEllipse);
        menuShapes->addAction(actionRectangle);
        menuShapes->addSeparator();
        menuShapes->addAction(actionFree_draw);
        menuEdition->addAction(actionAnnuler);
        menuEdition->addAction(actionClear);
        menuEdition->addSeparator();
        menuEdition->addAction(actionDelete);
        menuEdition->addSeparator();
        menuEdition->addAction(actionDraw);
        menuEdition->addAction(actionSelect);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionPen_color->setText(QApplication::translate("MainWindow", "Pen Color", 0, QApplication::UnicodeUTF8));
        actionPen_size->setText(QApplication::translate("MainWindow", "Pen Size", 0, QApplication::UnicodeUTF8));
        actionSquare_cap->setText(QApplication::translate("MainWindow", "Square Cap", 0, QApplication::UnicodeUTF8));
        actionFlat_cap->setText(QApplication::translate("MainWindow", "Flat Cap", 0, QApplication::UnicodeUTF8));
        actionRound_cap->setText(QApplication::translate("MainWindow", "Round Cap", 0, QApplication::UnicodeUTF8));
        actionBevel_join->setText(QApplication::translate("MainWindow", "Bevel Join", 0, QApplication::UnicodeUTF8));
        actionMiter_join->setText(QApplication::translate("MainWindow", "Miter Join", 0, QApplication::UnicodeUTF8));
        actionRound_join->setText(QApplication::translate("MainWindow", "Round Join", 0, QApplication::UnicodeUTF8));
        actionEllipse->setText(QApplication::translate("MainWindow", "Ellipse", 0, QApplication::UnicodeUTF8));
        actionLine->setText(QApplication::translate("MainWindow", "Line", 0, QApplication::UnicodeUTF8));
        actionRectangle->setText(QApplication::translate("MainWindow", "Rectangle", 0, QApplication::UnicodeUTF8));
        actionPolygon->setText(QApplication::translate("MainWindow", "Polygon", 0, QApplication::UnicodeUTF8));
        actionFree_draw->setText(QApplication::translate("MainWindow", "Free Draw", 0, QApplication::UnicodeUTF8));
        actionDraw->setText(QApplication::translate("MainWindow", "Draw", 0, QApplication::UnicodeUTF8));
        actionSelect->setText(QApplication::translate("MainWindow", "Select", 0, QApplication::UnicodeUTF8));
        actionAnnuler->setText(QApplication::translate("MainWindow", "Cancel", 0, QApplication::UnicodeUTF8));
        actionAnnuler->setShortcut(QApplication::translate("MainWindow", "Ctrl+Z", 0, QApplication::UnicodeUTF8));
        actionClear->setText(QApplication::translate("MainWindow", "Clear", 0, QApplication::UnicodeUTF8));
        actionClear->setShortcut(QApplication::translate("MainWindow", "Ctrl+R", 0, QApplication::UnicodeUTF8));
        actionPolyline->setText(QApplication::translate("MainWindow", "Polyline", 0, QApplication::UnicodeUTF8));
        actionAntialiasing->setText(QApplication::translate("MainWindow", "Antialiasing", 0, QApplication::UnicodeUTF8));
        actionSave->setText(QApplication::translate("MainWindow", "Save", 0, QApplication::UnicodeUTF8));
        actionSave->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", 0, QApplication::UnicodeUTF8));
        actionOpen->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        actionDelete->setText(QApplication::translate("MainWindow", "Delete", 0, QApplication::UnicodeUTF8));
        actionDelete->setShortcut(QApplication::translate("MainWindow", "Del", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "Pen attributes", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Pen", 0, QApplication::UnicodeUTF8));
        penSizeLabel->setText(QApplication::translate("MainWindow", "Pen Size :", 0, QApplication::UnicodeUTF8));
        capStyleLabel->setText(QApplication::translate("MainWindow", "Pen Cap Style :", 0, QApplication::UnicodeUTF8));
        capStyleComboBox->clear();
        capStyleComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Square Cap", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Flat Cap", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Round Cap", 0, QApplication::UnicodeUTF8)
        );
        joinStyleComboBox->clear();
        joinStyleComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Bevel Join", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Miter Join", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Round Join", 0, QApplication::UnicodeUTF8)
        );
        joinStyleLabel->setText(QApplication::translate("MainWindow", "Pen Join Style :", 0, QApplication::UnicodeUTF8));
        colorSelectionLabel->setText(QApplication::translate("MainWindow", "Pen color :", 0, QApplication::UnicodeUTF8));
        AACheckBox->setText(QApplication::translate("MainWindow", "Antialiasing", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Shape", 0, QApplication::UnicodeUTF8));
        fillCheckBox->setText(QApplication::translate("MainWindow", "Fill Shape", 0, QApplication::UnicodeUTF8));
        fillRuleComboBox->clear();
        fillRuleComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Odd Even Fill", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Winding Fill", 0, QApplication::UnicodeUTF8)
        );
        label->setText(QApplication::translate("MainWindow", "Type :", 0, QApplication::UnicodeUTF8));
        shapeTypeComboBox->clear();
        shapeTypeComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Line", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "PolyLine", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Polygon", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Ellipse", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Rectangle", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Free Draw", 0, QApplication::UnicodeUTF8)
        );
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Mode", 0, QApplication::UnicodeUTF8));
        drawRadioButton->setText(QApplication::translate("MainWindow", "Draw", 0, QApplication::UnicodeUTF8));
        selectRadioButton->setText(QApplication::translate("MainWindow", "Select", 0, QApplication::UnicodeUTF8));
        menuFichier->setTitle(QApplication::translate("MainWindow", "File", 0, QApplication::UnicodeUTF8));
        menuStylo->setTitle(QApplication::translate("MainWindow", "Pen", 0, QApplication::UnicodeUTF8));
        menuPen_join_style->setTitle(QApplication::translate("MainWindow", "Pen cap style...", 0, QApplication::UnicodeUTF8));
        menuPen_join_style_2->setTitle(QApplication::translate("MainWindow", "Pen Join Style...", 0, QApplication::UnicodeUTF8));
        menuShapes->setTitle(QApplication::translate("MainWindow", "Shape", 0, QApplication::UnicodeUTF8));
        menuEdition->setTitle(QApplication::translate("MainWindow", "Edit", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
