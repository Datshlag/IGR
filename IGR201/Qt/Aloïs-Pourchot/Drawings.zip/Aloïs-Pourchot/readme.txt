Fonctionnalités traitées: 
* L'utilisateur peut choisir la forme qu'il souhaite dessiner ainsi que plusieurs de ses caractéristiques, telles que sa couleur, le style du crayon, la 
taille du crayon, le remplissage ... Ces choix peuvent se faire via le menu, ou l'interface proposée à gauche.

* Les formes proposées sont les suivantes : ligne, multiligne, polygone, rectangle, ellipse et dessin libre. La plupart sont intuitives à dessiner. Pour multiligne et Polygone,
on rentre les points au fur et à mesure avec un clic gauche et on termine la forme avec un clic droit.

* L'utilisateur peut sauvegarder son travail, et le recharger après. Pour essayer ces fonctions, vous pouvez regarder les fichiers dans "Drawings"

* Il est possible pour l'utilisateur d'annuler sa dernière saisie avec un ctrl-z, mais cette fonction n'est pas recommandée car elle ne fonctionne pas très bien:
la mainwindow ne donne pas toujours le focus et il faut parfois le faire à la main avec le menu "Edit", et est en plus peu user friendly : il n'y a pas de "recommencer",
la fonction se contente de supprimer le dernier élément dessiné. 

* Il y a une fonction clear, dont le résultat est explicite

* L'utilisateur peut passer en mode sélection pour sélectionner, déplacer voire supprimer une forme qu'il a dessinée auparavant. 

