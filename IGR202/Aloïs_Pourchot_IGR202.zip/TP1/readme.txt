Informatique Graphique 3D et R�alit� Virtuelle
---------------------------------------------- 
Travaux Pratique: base source code for assignments/practice/projects

Compilation
-----------
Edit the Makefile to adjust it to your machine configuration and type make.

Execution
---------
./main models/<fichier.off>

Contact: Tamy Boubekeur (tamy.boubekeur@telecom-paristech.fr)